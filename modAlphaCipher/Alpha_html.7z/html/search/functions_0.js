var searchData=
[
  ['convert_14',['convert',['../classmodAlphaCipher.html#a12ace58352c18bac7a7b61f312a4c8d6',1,'modAlphaCipher::convert(const std::wstring &amp;s)'],['../classmodAlphaCipher.html#ac86303da1bf6467d3afd928a0e781f97',1,'modAlphaCipher::convert(const std::vector&lt; int &gt; &amp;v)']]]
];
