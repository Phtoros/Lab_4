var indexSectionsWithContent =
{
  0: "cdkp",
  1: "cp",
  2: "p",
  3: "cdp",
  4: "k"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Файлы",
  3: "Функции",
  4: "Переменные"
};

